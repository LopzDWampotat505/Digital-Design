library IEEE;
use IEEE.std_logic_1164.all;
 
entity testbench is
-- empty
end testbench; 

architecture tb of testbench is

-- DUT component
component ent_mon is
port(
  A: in std_logic;
  B: in std_logic;
  C: in std_logic;
  MON: out std_logic_vector(2 downto 0));
end component;

signal a_in, b_in, c_in: std_logic;
signal MON_out: std_logic_vector(2 downto 0);

begin

  -- Connect UUT
  UUT: ent_mon port map(a_in, b_in, c_in, MON_out);
  
  process
  begin

  	a_in <= '0';
    b_in <= '0';
    c_in <= '0';
    wait for 1 ns;
  
  
    a_in <= '0';
    b_in <= '0';
    c_in <= '1';
    wait for 1 ns;

    a_in <= '0';
    b_in <= '1';
    c_in <= '0';
    wait for 1 ns;
    

    a_in <= '0';
    b_in <= '1';
    c_in <= '1';
    wait for 1 ns;
 
    a_in <= '1';
    b_in <= '0';
    c_in <= '0';
    wait for 1 ns;
    
 
    a_in <= '1';
    b_in <= '0';
    c_in <= '1';
    wait for 1 ns;
    

    a_in <= '1';
    b_in <= '1';
    c_in <= '0';
    wait for 1 ns;
  
    a_in <= '1';
    b_in <= '1';
    c_in <= '1';
    wait for 1 ns;
    
   
    
  end process;
end tb;